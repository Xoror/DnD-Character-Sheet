const BudgetBackground = {
	backgroundColor: "#33ff46",
};

export const styles = {
	BudgetBackground: BudgetBackground,
}